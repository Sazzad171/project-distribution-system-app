


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
  <div class="page-body">
    <div class="container-fluid">
      <div class="page-title">
        <div class="row">
          <div class="col-6">
            <h3>Register New Timeline</h3>
          </div>
          <div class="col-6">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i data-feather="home"></i></a></li>
              <li class="breadcrumb-item active">Register New Timeline</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!-- Container-fluid starts-->
    <div class="container-fluid">

      <!-- register new project start -->
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-sm-8">
              <h5>Research Project Registration Form</h5>
              <span>Fill out this form.</span>
            </div>
          </div>
          
        </div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('timeline.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3 row">
              <label class="col-sm-3 col-form-label">Current Semester</label>
              <div class="col-sm-9">
                <select name="tl_semester" class="form-control">
                  <option value="">Select a semester</option>
                  <?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($semester->sem_id); ?>"><?php echo e($semester->sem_title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['tl_semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="mb-3 row">
              <label class="col-sm-3 col-form-label">Start Date and time</label>
              <div class="col-sm-9">
                <input class="form-control digits" type="datetime-local" name="tl_start" value="<?php echo e(old('tl_start')); ?>">
                <?php $__errorArgs = ['tl_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="mb-3 row">
              <label class="col-sm-3 col-form-label">End Date and time</label>
              <div class="col-sm-9">
                <input class="form-control digits" type="datetime-local" name="tl_end" value="<?php echo e(old('tl_end')); ?>">
                <?php $__errorArgs = ['tl_end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="mb-3 row">
              <label class="col-sm-3 col-form-label">Select All Field/Area</label>
              <div class="col-sm-9">
                <div class="animate-chk">
                  <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label for="field<?php echo e($field->fld_id); ?>" class="me-3">
                      <input class="checkbox_animated" id="field<?php echo e($field->fld_id); ?>" name="tl_field[]" type="checkbox" value="<?php echo e($field->fld_id); ?>"> 
                      <?php echo e($field->fld_name); ?>

                    </label>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php $__errorArgs = ['tl_field'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <button class="btn btn-primary" type="submit">Submit form</button>
          </form>
        </div>
      </div>
      <!-- register new project end -->

    </div>
    <!-- Container-fluid Ends-->
  </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ju-project-distribution-system\admin\resources\views/timeline/addTimeline.blade.php ENDPATH**/ ?>