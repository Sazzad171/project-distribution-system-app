


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
  <div class="page-body">
    <div class="container-fluid">
      <div class="page-title">
        <div class="row">
          <div class="col-6">
            <h3>Assign Supervisor</h3>
          </div>
          <div class="col-6">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i data-feather="home"></i></a></li>
              <li class="breadcrumb-item active">Assign Supervisor</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!-- Container-fluid starts-->
    <div class="container-fluid">

      <!-- register new project start -->
      <div class="card">
        <div class="card-body">
          
          <div class="row">
            <div class="col-12">
              <h6 class="text-underline mb-3">Student Registration Information:</h6>
            </div>

            <div class="col-md-3 mb-3 mb-md-1">
              <p><b>Student Name:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-1">
              <p><?php echo e($studentRegistrationData->student->std_name); ?></p>
            </div>

            
            <?php for($i=0; $i < 15; $i++): ?>
            <p class="d-none"><?php echo e($temp = "field".$i); ?></p>
            <?php if($studentRegistrationData->$temp !== null): ?>

            <div class="col-md-3 mb-3 mb-md-1">
              <p><b>Prefered Field/Area <?php echo e($i); ?>:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-1">
              <p><?php echo e($studentRegistrationData->$temp); ?></p>
            </div>

            <?php endif; ?>
            <?php endfor; ?>

            <div class="col-md-3 mb-3 mb-md-1">
              <p><b>Semester:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-1">
              <p><?php echo e($studentRegistrationData->semester->sem_title); ?></p>
            </div>
          </div>

          <hr class="my-4">

          
          <h6 class="text-underline mb-3">Assign Supervisor:</h6>
          <form method="POST" action="<?php echo e(route('pendingRegisteredStudents.newProject')); ?>">
            <?php echo csrf_field(); ?>

            
            <input type="hidden" name="studentId" value="<?php echo e($studentRegistrationData->student->std_id); ?>">
            <input type="hidden" name="stdRegId" value="<?php echo e($studentRegistrationData->std_reg_id); ?>">
            <input type="hidden" name="sem_id" value="<?php echo e($studentRegistrationData->semester->sem_id); ?>">

            <div class="mb-3 row">
              <label class="col-sm-3 col-form-label">Select Teacher</label>
              <div class="col-sm-9">
                <select class="form-control" name="assigned_supervisor">
                  <option value="">Select a supervisor</option>
                  <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($teacher->tchr_id); ?>"><?php echo e($teacher->tchr_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['assigned_supervisor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            
            <button class="btn btn-primary" type="submit">Submit form</button>
          </form>
        </div>
      </div>
      <!-- register new project end -->

    </div>
    <!-- Container-fluid Ends-->
  </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ju-project-distribution-system\admin\resources\views/pending-registered-students/assign-supervisor.blade.php ENDPATH**/ ?>