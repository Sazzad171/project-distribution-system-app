


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="page-body">
    <div class="container-fluid">
      <div class="page-title">
        <div class="row">
          <div class="col-6">
            <h3>Students</h3>
          </div>
          <div class="col-6">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i data-feather="home"></i></a></li>
              <li class="breadcrumb-item active">Students</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!-- Container-fluid starts-->
    <div class="container-fluid">

      <!-- students table start -->
      <div class="card">
        <div class="card-header p-3">
          <div class="row align-items-center">
            <div class="col-md-8">
              <h6>All Students</h6>
            </div>
            <div class="col-md-4">
              <p class="text-md-end">
                <a href="<?php echo e(route('student.create')); ?>" class="btn btn-primary">Add New Students</a>
              </p> 
            </div>
          </div>
        </div>
        <div class="card-body">
          <!-- table -->
          <div class="table-responsive mb-4">
            <table class="table table-bordered">
              <thead class="table-primary">
                <tr>
                  <th>Name</th>
                  <th>ID</th>
                  <th>Email</th>
                  <th>Reg. Status</th>
                  <th>Research/Project Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php if (! (count($students) === 0)): ?>

                  <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($student->std_name); ?></td>
                      <td><?php echo e($student->std_varsity_id); ?></td>
                      <td><?php echo e($student->std_email); ?></td>
                      <td>
                        <?php if (! ( $student->studentRegistration === null )): ?>
                        <?php echo e($student->studentRegistration->std_reg_status); ?>

                        <?php endif; ?>
                      </td>
                      <td class="text-center">
                        
                        <?php if (! ( $student->studentProject === null )): ?>
                        <?php echo e($student->studentProject->status); ?>

                        <?php endif; ?>
                      </td>
                      <td class="text-end">
                        <a href="<?php echo e(route('student.edit', $student->std_id)); ?>" class="btn btn-warning-gradien" type="button"><i class="fa fa-edit"></i></a>
                        <a href="<?php echo e(route('student.delete', $student->std_id)); ?>" class="btn btn-danger-gradien" type="button"><i class="fa fa-trash"></i></a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                  <tr>
                    <td colspan="5">
                      <p class="text-center">No student found!</p>
                    </td>
                  </tr>

                <?php endif; ?>
              </tbody>
            </table>
          </div>

          
          
        </div>
      </div>
      <!-- students table end -->

    </div>
    <!-- Container-fluid Ends-->
  </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ju-project-distribution-system\admin\resources\views/student/students.blade.php ENDPATH**/ ?>