


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
  <div class="page-body">
    <div class="container-fluid">
      <div class="page-title">
        <div class="row">
          <div class="col-6">
            <h3>Student Project Details</h3>
          </div>
          <div class="col-6">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i data-feather="home"></i></a></li>
              <li class="breadcrumb-item active">Project deatils</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!-- Container-fluid starts-->
    <div class="container-fluid">

      <!-- register new project start -->
      <div class="card">
        <div class="card-body">
          
          <div class="row">
            <div class="col-12">
              <h6 class="text-underline mb-3">Student Project Information:</h6>
            </div>

            <div class="col-md-3 mb-3 mb-md-2">
              <p><b>Student Name:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-2">
              <p><?php echo e($project->student->std_name); ?></p>
            </div>

            <div class="col-md-3 mb-3 mb-md-2">
              <p><b>Student ID:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-2">
              <p><?php echo e($project->student->std_varsity_id); ?></p>
            </div>

            <div class="col-md-3 mb-3 mb-md-2">
              <p><b>Teacher Name:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-2">
              <p><?php echo e($project->teacher->tchr_name); ?></p>
            </div>

            <div class="col-md-3 mb-3 mb-md-2">
              <p><b>Project Name:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-2">
              <p><?php echo e($project->std_proj_name); ?></p>
            </div>

            <div class="col-md-3 mb-3 mb-md-2">
              <p><b>Registered Semester:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-2">
              <p><?php echo e($project->semester->sem_title); ?></p>
            </div>

            <div class="col-md-3 mb-3 mb-md-2">
              <p><b>Project Status:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-2">
              <p><?php echo e($project->status); ?></p>
            </div>

            <div class="col-md-3 mb-3 mb-md-2">
              <p><b>Public project:</b> </p>
            </div>
            <div class="col-md-9 mb-3 mb-md-2">
              <p><?php echo e($project->public_project); ?></p>
            </div>

          </div>
        </div>
      </div>
      <!-- register new project end -->

    </div>
    <!-- Container-fluid Ends-->
  </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ju-project-distribution-system\admin\resources\views/student-projects/details.blade.php ENDPATH**/ ?>