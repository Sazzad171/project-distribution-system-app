@include('layout.partials.header')

@yield('main-content')

@include('layout.partials.footer')